import { Injectable } from '@angular/core';

@Injectable()

export class AppConstaints{
  public GEAR_TYPES ={
      '1':  "Manually",
      '2' : "Mechanic",
      '5' : "Automatic",
      '6' : "Stepless"
  };
}

