/// <reference path="globals/cordova/index.d.ts" />
